import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Carts } from '../models/cart';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  constructor(private httpclient:HttpClient){}
  
  adduserdata(myuser:any){
    return this.httpclient.post("http://localhost:3000/userdata",myuser)
  }

  login(emailid: string, password: string) {
    return this.httpclient.get<string[]>("http://localhost:3000/userdata?emailiD=" + emailid + "&password=" + password);
  }

  checkIfuserExist(emailid:string){
    return this.httpclient.get<string[]>("http://localhost:3000/userdata?emailiD="+ emailid)
  }

  role(role:string){
    return this.httpclient.get<string>("http://localhost:3000/userdata?role="+ role)
  }
  
  getcartdetails(emailid: string) {
    return this.httpclient.get<Carts[]>("http://localhost:3000/cartdetails?emailiD=" + emailid);
  }
  

  addCart(cartdata:Carts) {
    return this.httpclient.post("http://localhost:3000/cartdetails", cartdata);
  }

  
}
