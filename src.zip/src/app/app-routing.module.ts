import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddcakesComponent } from './addcakes/addcakes.component';
import { ViewonecakeComponent } from './viewonecake/viewonecake.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { authGuard } from './auth.guard';
import { guardcloseGuard } from './guardclose.guard';
import { OrderpageComponent } from './orderpage/orderpage.component';
import { CustomerorderdetailsComponent } from './customerorderdetails/customerorderdetails.component';
import { ErrorComponent } from './error/error.component';
import { OrderdetailsComponent } from './orderdetails/orderdetails.component';
import { orderAuthGuard } from './order-auth.guard';


const routes: Routes = [
  {
    path:"",
    component:HomeComponent
  },
  {
    path:"addCake",
    component:AddcakesComponent,
    canActivate:[authGuard]
    
  },
  {
    path:"viewallcakes",
    redirectTo:""
  },
  {
    path:"viewonecake/:id",
    component:ViewonecakeComponent
  },
  {
    path:"editdetails/:id",
    component:AddcakesComponent,
    canActivate:[authGuard]
    
  },
  {
    path:"login",
    component:LoginComponent,
    canDeactivate:[guardcloseGuard]
  },
  {
    path:"register",
    component:RegisterComponent
  },
  {
    path:"orderpage/:id",
    component:OrderpageComponent,
    canActivate:[orderAuthGuard]
  },
  {
    path:"ordercustomerdetails/:id",
    component:OrderdetailsComponent,
    
  },
  {
    path:"orderdetails",
    component:CustomerorderdetailsComponent,
    canActivate:[authGuard]
  },
  {
    path:"**",
    component:ErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
