import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { UserserviceService } from '../userservice/userservice.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  constructor(private fb:FormBuilder,private snackbar:MatSnackBar, private userserv:UserserviceService){

  }
  userModel=this.fb.group({
    username: ['',[Validators.required,Validators.minLength(5),Validators.maxLength(30), Validators.pattern('[A-Za-z]*')]
    ],
    
    emailiD: ['', [Validators.required, Validators.email]],

    phoneNo: ['', [Validators.required, Validators.pattern("^\\d{10}$")]],

    role:['user'],
   
    password: ['', [Validators.required, Validators.minLength(8)]],
    
    confirmpassword: ['', Validators.required],

    address:['',Validators.required],

    pincode: ['', [Validators.required, Validators.pattern("[0-9]{6}")]]

   
  },{validators:this.passwordCheck})


  get username(){
    return this.userModel.get("username");
  }
  get role(){
    return this.userModel.get("role");
  }
  get emailiD(){
    return this.userModel.get("emailiD");
  }
  get phoneNo(){
    return this.userModel.get("phoneNo");
  }
  
  get pincode(){
    return this.userModel.get("pincode")
  }
  get address(){
    return this.userModel.get("address")
  }
  
  get password()
  {
    return this.userModel.get('password');
  }
  get confirmpassword()
  {
    return this.userModel.get('confirmpassword');
  }
  
  passwordCheck(ac:AbstractControl)
  
  {
    let pass=ac.get('password')?.value;
    let cpass=ac.get('confirmpassword')?.value;
    if(pass==cpass)
    {
      return null;
    }
    else
    {
      return{passerror:"incorrect password"}
    }
  }

  
  addUsers(){
    const emailid=this.userModel.value.emailiD!
    
    this.userserv.checkIfuserExist(emailid).subscribe((data)=>{
      
      if(data.length !==0 ){
        this.snackbar.open('Already Registered','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
        
      }
      else{
        this.userserv.adduserdata(this.userModel.value).subscribe(()=>{
          this.snackbar.open('you joined us successfully ','enjoy!!',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
         
         
        })
        
      }
    })
  }

 visible: boolean = false;

togglePasswordVisibility() {
  this.visible = !this.visible;
}

}