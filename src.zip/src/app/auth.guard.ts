import { Injectable, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateFn, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { LoginService } from './userservice/login.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn:'root'
})


export class authGuard implements CanActivate {
 constructor(private logserv:LoginService,private roter:Router){}
 canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
   if(this.logserv.isAdmin){
      return true
   }
   else{
    this.roter.navigateByUrl("login")
    return false
   }
 }
};
