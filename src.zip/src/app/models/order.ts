export type Order={
    id?:number,
    name?:string,
    emailID?:string,
    address?:string,
    phoneno?:string,
    pincode?:number,
    deliveryDate?:string,
    price?:number,
    catagories?:string,
    Quantity?:number,
    total?:number,
    imageurl?:string,
    cakemsg?:string
    
}