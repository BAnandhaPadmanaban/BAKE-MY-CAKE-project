export type Cake={

    id?:number,
    imageurl?:string,
    description?:string,
    price?:number,
    catagories?:string,
    
}