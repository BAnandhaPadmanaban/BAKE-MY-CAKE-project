import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Cake } from '../models/cake';
import { Carts } from '../models/cart';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CakeserviceService {

  constructor(private httpclient:HttpClient) {
  }

  editcake(myCake:Cake)
  {
   return this.httpclient.put<Cake>("http://localhost:3000/cakedetails/"+myCake.id,myCake);
  }

  addCake(myCake:Cake)
  {
   return this.httpclient.post<Cake>("http://localhost:3000/cakedetails",myCake);
  }

  deleteDetails(id:number){
    return this.httpclient.delete<Cake>("http://localhost:3000/cakedetails/"+id);
  }

  getCakes()
  {
    return this.httpclient.get<Cake[]>("http://localhost:3000/cakedetails");
  }
  getCakeById(id:number)
  {
    return this.httpclient.get<Cake>("http://localhost:3000/cakedetails/"+id);
  }
  getCakeByName(name:string){
    return this.httpclient.get<Cake[]>("http://localhost:3000/cakedetails?catagories="+name)
  }
  addCart(cartdetails:Carts)
  {
   return this.httpclient.post<Carts>("http://localhost:3000/cartdetails",cartdetails);
  }
  getcartdetails(){
    return this.httpclient.get<Carts[]>("http://localhost:3000/cartdetails");
  }
  checkuserexist(emailid:string){
    return this.httpclient.get<Carts>("http://localhost:3000/cartdetails?emailiD="+emailid)
  }
  updateCart(cartdetails:any) {
    return this.httpclient.post<any>("http://localhost:3000/cartdetails/cartItems", cartdetails);
  }
  getCakeByFirstLetter(firstLetter: string): Observable<Cake[]> {
    return this.httpclient.get<Cake[]>(`http://localhost:3000/cakedetails?catagories_like=${firstLetter}`);
  }
}
