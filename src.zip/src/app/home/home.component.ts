import { Component, OnInit } from '@angular/core';
import { CakeserviceService } from '../services/cakeservice.service';
import { Cake } from '../models/cake';
import { LoginService } from '../userservice/login.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 
cakedata:Cake[] = [];

constructor(private cakeserv: CakeserviceService,private snackbar:MatSnackBar, public logserv:LoginService) {}

  ngOnInit(): void {
    this.getAllCake();
  }
  
   
    getAllCake(): void {
    this.cakeserv.getCakes().subscribe(allcakes => {
      this.cakedata = allcakes;
    });
  }

 
  deleteCake(id: any): void {
    this.cakeserv.deleteDetails(id).subscribe(data => {
      this.snackbar.open('Cake deleted successfully','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
      
      this.getAllCake();
    });
  }

 
 
  filterByName(event:any){
    if(event==''){
      this.cakeserv.getCakes().subscribe(allcakes => {
        this.cakedata = allcakes;
      });
    }
    else {
     
      if (event.length === 1) {
        
        this.cakeserv.getCakeByFirstLetter(event).subscribe((data) => this.cakedata = data);
      } else {
        
        this.cakeserv.getCakeByName(event).subscribe((data) => this.cakedata = data);
      }
    }
  }
}
