import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserserviceService } from '../userservice/userservice.service';
import { LoginService } from '../userservice/login.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

openSnackBar(message: string, action: string, duration: number) {
  this.snackBar.open(message, action, {
    duration: duration,
  });
}

constructor(private fb:FormBuilder,private snackbar:MatSnackBar, private userserv:UserserviceService,private    router:Router,private logserv:LoginService,public snackBar: MatSnackBar){}

userModel=this.fb.group({

  emailiD: ['', [Validators.required, Validators.email]],

  password: ['', [Validators.required, Validators.minLength(8)]]

})
get emailiD(){
  return this.userModel.get("emailiD");
}
get password()
{
  return this.userModel.get('password');
}
visible: boolean = false;

togglePasswordVisibility() {
  this.visible = !this.visible;
}

canclose(){
  if(this.userModel.invalid){
    let response=confirm("Do you want to leave this page")
    return response;
  }
  else{
    return true;
  }
}

getUserEmailPass() {

  const emailiD = this.userModel.value.emailiD!;
  const password = this.userModel.value.password!;

  
    this.userserv.login(emailiD, password).subscribe(data => {
      
      if (data.length === 1) {
        
        this.logserv.loginPage(data)
        this.snackbar.open('login successfully','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
        
        this.router.navigateByUrl("")
      } else {
        this.snackbar.open('User not found, please make register','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
        
      }
    });
   
  }
} 




